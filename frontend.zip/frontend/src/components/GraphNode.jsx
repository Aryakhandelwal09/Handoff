import { Handle, Position } from "reactflow";
import "./GraphNode.css";

const ICONS = {
  entry: "🚪",
  core: "⚙️",
  data: "🗄️",
  config: "🔑"
};

export default function GraphNode({ data }) {
  const { name, category, readingOrderStep, meta, flags, dimmed, selected } = data;

  return (
    <div className={`graph-node tag-${category} ${dimmed ? "dimmed" : ""} ${selected ? "selected" : ""}`}>
      <Handle type="target" position={Position.Top} style={{ opacity: 0 }} />
      <div className="node-accent" />
      <div className="node-header">
        <span className="node-badge">{readingOrderStep ?? "·"}</span>
        <span className="node-icon">{ICONS[category] || "📄"}</span>
        <span className="node-name">{name}</span>
      </div>
      <div className="node-body">
        <div className="node-meta">{meta}</div>
        {flags && flags.length > 0 && (
          <span className="node-tag flag">{flags[0]}</span>
        )}
      </div>
      <Handle type="source" position={Position.Bottom} style={{ opacity: 0 }} />
    </div>
  );
}
