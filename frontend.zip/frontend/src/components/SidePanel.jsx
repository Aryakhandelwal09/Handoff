import { useState } from "react";
import "./SidePanel.css";

export default function SidePanel({ selectedNode, checklist, checkedItems, onToggleItem }) {
  const [tab, setTab] = useState("explain");

  return (
    <div className="side-panel">
      <div className="panel-tabs">
        <div className={`panel-tab ${tab === "explain" ? "active" : ""}`} onClick={() => setTab("explain")}>
          Explanation
        </div>
        <div className={`panel-tab ${tab === "checklist" ? "active" : ""}`} onClick={() => setTab("checklist")}>
          Checklist
        </div>
      </div>

      {tab === "explain" && (
        <div className="panel-content">
          {selectedNode ? (
            <>
              <h3>{selectedNode.name}</h3>
              <div className="file-path">{selectedNode.path}</div>
              <p>{selectedNode.explanation}</p>
            </>
          ) : (
            <p>Click a node in the graph to see its explanation.</p>
          )}
        </div>
      )}

      {tab === "checklist" && (
        <div className="panel-content">
          <div className="checklist">
            {checklist.map((item, i) => (
              <label key={i} className={`check-item ${checkedItems[i] ? "done" : ""}`}>
                <input
                  type="checkbox"
                  checked={!!checkedItems[i]}
                  onChange={() => onToggleItem(i)}
                />
                {item.text}
                {item.warning && <span className="warn">⚠ {item.warning}</span>}
              </label>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
