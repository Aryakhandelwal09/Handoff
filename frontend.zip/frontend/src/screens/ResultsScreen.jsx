import { useMemo, useState, useCallback, useEffect } from "react";
import ReactFlow, { Background, Controls, MarkerType } from "reactflow";
import "reactflow/dist/style.css";
import GraphNode from "../components/GraphNode";
import SidePanel from "../components/SidePanel";
import { RoleSelector, ProgressStrip } from "../components/TopControls";
import SummaryCard from "../components/SummaryCard";
import "./ResultsScreen.css";

const nodeTypes = { handoffNode: GraphNode };

function layoutNodes(nodes) {
  const ordered = [...nodes].sort((a, b) => {
    if (a.readingOrderStep == null && b.readingOrderStep == null) return 0;
    if (a.readingOrderStep == null) return 1;
    if (b.readingOrderStep == null) return -1;
    return a.readingOrderStep - b.readingOrderStep;
  });

  const COLS = 3;
  return ordered.map((node, i) => {
    const col = i % COLS;
    const row = Math.floor(i / COLS);
    const zigzagY = row % 2 === 0 ? 0 : 60;
    return {
      ...node,
      position: { x: col * 230 + 60, y: row * 170 + zigzagY + 40 }
    };
  });
}

export default function ResultsScreen({ analysis, onNewRepo }) {
  const { repoName, nodes: rawNodes, checklist, summary, degraded, degradedReason } = analysis;

  const [activeRole, setActiveRole] = useState("fullstack");
  const [selectedNodeId, setSelectedNodeId] = useState(null);
  const [hoveredNodeId, setHoveredNodeId] = useState(null);

  const storageKey = `handoff-checklist-${repoName}`;
  const [checkedItems, setCheckedItems] = useState(() => {
    try {
      const saved = localStorage.getItem(storageKey);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(storageKey, JSON.stringify(checkedItems));
    } catch {
      // localStorage unavailable — progress just won't persist, not fatal
    }
  }, [checkedItems, storageKey]);

  const positioned = useMemo(() => layoutNodes(rawNodes), [rawNodes]);

  const flowNodes = useMemo(() => {
    return positioned.map(n => {
      const dimmed = activeRole !== "other" && !n.role.includes(activeRole);
      return {
        id: n.id,
        type: "handoffNode",
        position: n.position,
        data: {
          name: n.name,
          category: n.category,
          readingOrderStep: n.readingOrderStep,
          meta: n.flags?.length ? `${n.flags.length} flag(s)` : `${n.connections?.length || 0} connections`,
          flags: n.flags,
          dimmed,
          selected: n.id === selectedNodeId
        }
      };
    });
  }, [positioned, activeRole, selectedNodeId]);

  const flowEdges = useMemo(() => {
    const byId = Object.fromEntries(positioned.map(n => [n.id, n]));
    const edges = [];

    positioned.forEach(n => {
      (n.connections || []).forEach(targetId => {
        if (!byId[targetId]) return;
        const isConnectedToHover = hoveredNodeId && (n.id === hoveredNodeId || targetId === hoveredNodeId);
        edges.push({
          id: `dep-${n.id}-${targetId}`,
          source: n.id,
          target: targetId,
          style: {
            stroke: isConnectedToHover ? "#8b7cf6" : "#3a3f52",
            strokeWidth: isConnectedToHover ? 2 : 1.4,
            opacity: hoveredNodeId && !isConnectedToHover ? 0.15 : 1
          }
        });
      });
    });

    const orderedWithStep = positioned
      .filter(n => n.readingOrderStep != null)
      .sort((a, b) => a.readingOrderStep - b.readingOrderStep);

    for (let i = 0; i < orderedWithStep.length - 1; i++) {
      edges.push({
        id: `order-${i}`,
        source: orderedWithStep[i].id,
        target: orderedWithStep[i + 1].id,
        style: { stroke: "#8b7cf6", strokeWidth: 2.5 },
        markerEnd: { type: MarkerType.ArrowClosed, color: "#4fd1c5" },
        animated: true
      });
    }

    return edges;
  }, [positioned, hoveredNodeId]);

  const selectedNode = rawNodes.find(n => n.id === selectedNodeId) || null;
  const doneCount = Object.values(checkedItems).filter(Boolean).length;

  const onNodeClick = useCallback((_, node) => setSelectedNodeId(node.id), []);
  const onNodeMouseEnter = useCallback((_, node) => setHoveredNodeId(node.id), []);
  const onNodeMouseLeave = useCallback(() => setHoveredNodeId(null), []);

  // Degraded mode: both AI providers failed. There's no graph or checklist
  // possible without AI, so show the README-based summary plainly instead
  // of trying to render an empty graph and side panel. This check sits
  // after every hook call above so hook order stays identical every render.
  if (degraded) {
    return (
      <section className="results-screen">
        <div className="topbar">
          <div className="repo-pill">{repoName}</div>
          <button className="pill-btn" onClick={onNewRepo}>New repo</button>
        </div>
        <div className="degraded-notice">
          <h3>Full analysis unavailable</h3>
          <p>{degradedReason}</p>
          <div className="degraded-summary">{summary}</div>
        </div>
      </section>
    );
  }

  return (
    <section className="results-screen">
      <div className="topbar">
        <div className="repo-pill">{repoName}</div>
        <button className="pill-btn" onClick={onNewRepo}>New repo</button>
      </div>

      <div className="subbar">
        <ProgressStrip done={doneCount} total={checklist.length} />
        <RoleSelector activeRole={activeRole} onChange={setActiveRole} />
      </div>

      <SummaryCard repoName={repoName} baseSummary={summary} nodes={rawNodes} />

      <div className="results-body">
        <div className="canvas-wrap">
          <ReactFlow
            nodes={flowNodes}
            edges={flowEdges}
            nodeTypes={nodeTypes}
            onNodeClick={onNodeClick}
            onNodeMouseEnter={onNodeMouseEnter}
            onNodeMouseLeave={onNodeMouseLeave}
            fitView
            proOptions={{ hideAttribution: true }}
          >
            <Background color="#ffffff0c" gap={26} />
            <Controls showInteractive={false} />
          </ReactFlow>

          <div className="legend">
            <div className="legend-item"><span className="legend-dot" style={{ background: "var(--violet)" }} />Entry point</div>
            <div className="legend-item"><span className="legend-dot" style={{ background: "var(--teal)" }} />Core logic</div>
            <div className="legend-item"><span className="legend-dot" style={{ background: "var(--amber)" }} />Data</div>
            <div className="legend-item"><span className="legend-dot" style={{ background: "var(--rose)" }} />Config / flagged</div>
          </div>
        </div>

        <SidePanel
          selectedNode={selectedNode}
          checklist={checklist}
          checkedItems={checkedItems}
          onToggleItem={(i) => setCheckedItems(prev => ({ ...prev, [i]: !prev[i] }))}
        />
      </div>
    </section>
  );
}